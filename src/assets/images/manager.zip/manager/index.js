const apiUrl = 'https://65aa8b66081bd82e1d97344f.mockapi.io/books';
async function addUser() {
  const name = document.getElementById('name').value;
  const phone = document.getElementById('phone').value;
  const email = document.getElementById('email').value;

  const response = await fetch(apiUrl, { 
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name, phone, email }),
  });

  if (response.ok) {
    getUserList();
  } else {
    alert('Failed to add user');
  }
}

async function getUserList() {
  const response = await fetch(apiUrl);
  const users = await response.json();

  const userListElement = document.getElementById('userList');
  userListElement.innerHTML = '';

  users.forEach(user => {
    const userDiv = document.createElement('div');
    userDiv.innerHTML = `
    <p><strong>Name:</strong> ${user.name}</p>
    <p><strong>Phone:</strong> ${user.phone}</p>
    <p><strong>Email:</strong> ${user.email}</p>
    <button onclick="editUser('${user.id}')">Edit</button>
    <button onclick="deleteUser('${user.id}')">Delete</button>
    `;
    userListElement.appendChild(userDiv);
  });
}
async function editUser(userId) {
    const newName = prompt('Enter new name:');
    const newPhone = prompt('Enter new phone:');
    const newEmail = prompt('Enter new email:');
  
    const response = await fetch(`${apiUrl}/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name: newName, phone: newPhone, email: newEmail }),
    });
  
    if (response.ok) {
      getUserList();
    } else {
      alert('Failed to edit user');
    }
  }
  
async function deleteUser(userId) {
  const response = await fetch(`${apiUrl}/${userId}`, {
    method: 'DELETE',
  });

  if (response.ok) {
    getUserList();
  } else {
    alert('Failed to delete user');
  }
}

// Initial load
getUserList();
